"""Serve the HTML/CSS/JavaScript interface on this computer."""
import argparse
import base64
import io

from flask import Flask, jsonify, request, send_from_directory
from matplotlib.backends.backend_agg import FigureCanvasAgg

from AustinWong_TIDE import EXAMPLE, ROOT, TideAnalyzer, spectrum_csv
from tide_plots import VIEWS, make_figure


app = Flask(__name__, static_folder=str(ROOT / "web"), static_url_path="/assets")
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024


@app.get("/")
def home():
    return send_from_directory(app.static_folder, "index.html")


@app.errorhandler(413)
def too_large(_):
    return jsonify(error="The file pair exceeds the 12 MB upload limit."), 413


@app.post("/api/analyze")
def analyze():
    try:
        if request.form.get("example") == "1":
            control, edited, _ = EXAMPLE
        else:
            if not all(name in request.files and request.files[name].filename
                       for name in ("control", "edited")):
                raise ValueError("Choose a control AB1 and an edited AB1.")
            control, edited = (io.BytesIO(request.files[name].read()) for name in ("control", "edited"))
        params = {key: int(request.form[key]) for key in
                  ("max_indel", "start", "end", "alignment_start", "cut_after") if request.form.get(key)}
        result = TideAnalyzer(control, edited, request.form.get("guide", "")).decompose_traces(**params)
    except (ValueError, RuntimeError) as exc:
        return jsonify(error=str(exc)), 400
    images = []
    for view in VIEWS:
        buffer = io.BytesIO()
        FigureCanvasAgg(make_figure(result, view)).print_png(buffer)
        images.append(base64.b64encode(buffer.getvalue()).decode("ascii"))
    result.pop("traces")
    result.pop("qc")
    return jsonify(**result, images=images, csv=spectrum_csv(result))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    app.run(host="127.0.0.1", port=args.port, threaded=False)
