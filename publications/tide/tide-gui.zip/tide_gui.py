"""Run the local desktop TIDE analyzer."""
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from AustinWong_TIDE import EXAMPLE, TideAnalyzer, spectrum_csv
from tide_plots import VIEWS, make_figure


class TideWindow:
    def __init__(self, root):
        root.title("TIDE · Trace decomposition")
        root.geometry("1040x700")
        root.minsize(810, 600)
        frame = ttk.Frame(root, padding=16)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)
        frame.rowconfigure(0, weight=1)
        form = ttk.Frame(frame, padding=(0, 0, 20, 0))
        form.grid(row=0, column=0, sticky="ns")
        ttk.Label(form, text="TIDE", font=("Segoe UI", 23, "bold")).pack(anchor="w")
        ttk.Label(form, text="Trace decomposition").pack(anchor="w", pady=(0, 16))
        self.fields = {}
        for name in ("Control AB1", "Edited AB1", "Guide DNA", "Maximum indel (bp)",
                     "Alignment start", "Fit start", "Fit end", "Cut after base (overrides guide)"):
            ttk.Label(form, text=name).pack(anchor="w", pady=(7, 0))
            line = ttk.Frame(form)
            line.pack(fill="x")
            val = self.fields[name] = tk.StringVar()
            ttk.Entry(line, textvariable=val, width=25).pack(side="left", fill="x", expand=True)
            if name.endswith("AB1"):
                ttk.Button(line, text="Browse", command=lambda v=val: self.pick(v)).pack(side="right")
        ttk.Label(form, text="Blank bounds use the automatic window.").pack(anchor="w", pady=6)
        ttk.Button(form, text="Analyze traces", command=self.run).pack(fill="x", pady=(7, 2))
        ttk.Button(form, text="Load example", command=self.example).pack(fill="x", pady=2)
        self.save = ttk.Button(form, text="Export spectrum CSV", command=self.export)
        self.save.pack(fill="x", pady=2)
        output = ttk.Frame(frame)
        output.grid(row=0, column=1, sticky="nsew")
        self.summary = ttk.Label(output, font=("Segoe UI", 13, "bold"), wraplength=510)
        self.summary.pack(anchor="w", pady=(8, 3))
        self.note = ttk.Label(output, wraplength=490, justify="left")
        self.note.pack(anchor="w", pady=(0, 8))
        self.tabs = ttk.Notebook(output)
        self.tabs.pack(fill="both", expand=True)
        for title in VIEWS:
            self.tabs.add(ttk.Frame(self.tabs), text=title)
        self.tabs.bind("<<NotebookTabChanged>>", lambda _: self.draw())
        self.canvas = None
        self.result = None
        for val in self.fields.values():
            val.trace_add("write", lambda *_: self.invalidate())
        self.example()

    def invalidate(self):
        self.result = None
        self.summary.config(text="Ready to analyze")
        self.note.config(text="Run the analysis to see results for these inputs.")
        self.save.state(["disabled"])
        if self.canvas:
            self.canvas.get_tk_widget().destroy()
            self.canvas = None

    def pick(self, variable):
        name = filedialog.askopenfilename(filetypes=[("AB1 chromatogram", "*.ab1 *.abi"), ("All files", "*")])
        if name:
            variable.set(name)

    def example(self):
        for var, value in zip(self.fields.values(), [*EXAMPLE, 10, "", "", "", ""]):
            var.set(str(value))
        self.run()

    def run(self):
        self.invalidate()
        control, edited, guide, size, anchor, left, right, cut = [v.get().strip() for v in self.fields.values()]
        try:
            kwargs = {k: int(v) for k, v in
                      [("alignment_start", anchor), ("start", left), ("end", right), ("cut_after", cut)] if v}
            result = TideAnalyzer(control, edited, guide).decompose_traces(int(size), **kwargs)
        except (ValueError, RuntimeError) as exc:
            self.summary.config(text="Check analysis inputs")
            self.note.config(text=str(exc))
            return
        self.result = result
        self.summary.config(text=f"Estimated editing {result['efficiency']:.2f}%    ·    R² {result['r2']:.3f}")
        lo, hi = result["window"]
        location = "manual coordinate" if result["strand"] == "manual" else result["strand"] + " guide"
        self.note.config(text=f"Cut after base {result['cut']} ({location})   ·   "
                         f"Fit window {lo}–{hi} bp   ·   Read offset {result['offset']:+d} bp\n"
                         f"Upstream aberrant signal   Control {result['upstream'][0]:.1f}%   "
                         f"Edited {result['upstream'][1]:.1f}%\n" + " ".join(result["warnings"]))
        self.save.state(["!disabled"])
        self.draw()

    def draw(self):
        if not self.result or not self.tabs.select():
            return
        if self.canvas:
            self.canvas.get_tk_widget().destroy()
        active = self.tabs.select()
        fig = make_figure(self.result, self.tabs.tab(active, "text"))
        self.canvas = FigureCanvasTkAgg(fig, master=self.tabs.nametowidget(active))
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

    def export(self):
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="tide-spectrum.csv",
                                           filetypes=[("CSV", "*.csv")])
        if path and self.result:
            try:
                Path(path).write_text(spectrum_csv(self.result), encoding="utf-8")
            except OSError as exc:
                messagebox.showerror("Export failed", str(exc))


if __name__ == "__main__":
    root = tk.Tk()
    TideWindow(root)
    root.mainloop()
