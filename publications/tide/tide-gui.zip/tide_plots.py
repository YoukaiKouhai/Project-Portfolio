"""Figures shared by Tk, the local web app and notebooks."""
from matplotlib.figure import Figure
from matplotlib.ticker import MaxNLocator

from AustinWong_TIDE import BASES

VIEWS = ("Indel spectrum", "Aberrant signal", "Chromatograms", "+1 composition")
TEAL, BLUE, INK = "#08786f", "#476bad", "#21374a"
DYES = ("#138161", "#396bd0", "#344453", "#c54b42")


def make_figure(result, view=VIEWS[0]):
    fig = Figure(figsize=(7.6, 3.65), dpi=115, layout="constrained")
    ax = fig.subplots()
    cut = result["cut"] + .5
    if view == VIEWS[0]:
        rows = result["spectrum"]
        sizes = [r["size"] for r in rows]
        colors = [INK if r["size"] == 0 else TEAL if r["p"] < .001 else "#aab8c1" for r in rows]
        ax.bar(sizes, [r["percent"] for r in rows], color=colors, width=.75)
        ax.set(xlabel="Indel size (bp)", ylabel="Estimated frequency (%)",
               xticks=sizes if len(sizes) <= 25 else None)
        ax.set_ylim(bottom=0, top=max(5, max(r["percent"] for r in rows)*1.15))
    elif view == VIEWS[1]:
        qc = result["qc"]
        ax.axvspan(*result["window"], color=TEAL, alpha=.09, label="Fit window")
        ax.axvline(cut, color=BLUE, linestyle=":", label="Cut")
        for key, color in [("control", INK), ("edited", TEAL)]:
            ax.plot(qc["x"], qc[key], lw=1.1, color=color, label=key.capitalize())
        ax.set(xlabel="Control base position", ylabel="Aberrant signal (%)", ylim=(0, 103))
        ax.legend(ncol=4, fontsize=8, frameon=False, loc="upper left")
    elif view == VIEWS[2]:
        fig.clear()
        axes = fig.subplots(2, 1, sharex=True)
        for ax, trace, name in zip(axes, result["traces"], ("Control", "Edited")):
            for base, color, signal in zip(BASES, DYES, trace["signal"]):
                ax.plot(trace["x"], signal, color=color, label=base, lw=1.3)
            ax.axvline(cut, color=BLUE, linestyle=":")
            ax.set_ylabel(name + "\nintensity")
        axes[0].legend(ncol=4, fontsize=8, frameon=False, loc="upper left")
        axes[1].set_xlabel("Control base position")
    elif view == VIEWS[3]:
        composition = result["composition"]
        if not composition:
            ax.set_axis_off()
            ax.text(.5, .5, result["composition_note"], transform=ax.transAxes,
                    ha="center", va="center", wrap=True)
            return fig
        ax.bar(BASES, list(composition.values()), color=DYES, width=.55)
        ax.set(ylabel="Estimated composition (%)", xlabel="Base in the sequenced strand", ylim=(0, 100))
    else:
        raise ValueError("Unknown figure.")
    for axis in fig.axes:
        axis.spines[["top", "right"]].set_visible(False)
        axis.spines[["left", "bottom"]].set_color("#bcc8ce")
        axis.grid(axis="y", color="#dce4e7", lw=.7)
        axis.set_axisbelow(True)
        axis.tick_params(labelsize=9, colors=INK)
        if view != VIEWS[3] and (view != VIEWS[0] or len(result["spectrum"]) > 25):
            axis.xaxis.set_major_locator(MaxNLocator(integer=True))
    return fig
