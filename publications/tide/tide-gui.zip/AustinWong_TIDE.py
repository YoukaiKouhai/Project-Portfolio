"""Estimate signed indel sizes from paired Sanger chromatograms."""
import argparse
import csv
import io
import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from Bio import SeqIO
from Bio.Seq import reverse_complement
from scipy.optimize import nnls
from scipy.signal import correlate
from scipy.stats import t

BASES = "ACGT"
ROOT = Path(__file__).resolve().parent
EXAMPLE = (ROOT / "example1.ab1", ROOT / "example2.ab1", "ATCACTCTCGGCATGGACGA")


@dataclass
class Read:
    sequence: str
    peaks: np.ndarray
    scans: np.ndarray
    locations: np.ndarray


def read_ab1(source):
    """Read the base calls, their scan positions, and dye-ordered peak heights."""
    try:
        raw = SeqIO.read(source, "abi").annotations["abif_raw"]
        version = 2 if "PBAS2" in raw and "PLOC2" in raw else 1
        sequence = raw[f"PBAS{version}"].decode("ascii").upper()
        locations = np.asarray(raw[f"PLOC{version}"], dtype=int)
        order = raw["FWO_1"].decode("ascii")
        if sorted(order) != list(BASES):
            raise ValueError("Invalid AB1 dye order.")
        scans = np.column_stack([raw[f"DATA{9 + order.index(b)}"] for b in BASES])
        if (len(locations) != len(sequence) or not len(sequence)
                or locations.min() < 0 or locations.max() >= len(scans)
                or np.any(np.diff(locations) <= 0)):
            raise ValueError("Inconsistent AB1 peak locations.")
        scans = np.maximum(scans, 0)
        return Read(sequence, scans[locations].astype(float), scans, locations)
    except OSError as exc:
        raise ValueError(f"Could not read the sequencing file. {exc}") from exc
    except Exception as exc:
        raise ValueError("Could not decode an analyzed AB1 chromatogram. "
                         "Check that it contains base calls, peak positions and four dye channels.") from exc


def find_cut(sequence, guide):
    guide = "".join(guide.upper().split())
    if not re.fullmatch("[ACGT]{20}", guide):
        raise ValueError("Enter a 20-base DNA guide using A, C, G and T, without the PAM.")
    matches = []
    for strand, query, distance in [("forward", guide, 17),
                                     ("reverse", reverse_complement(guide), 3)]:
        matches.extend((m.start() + distance, strand)
                       for m in re.finditer(f"(?={query})", sequence))
    if len(matches) != 1:
        raise ValueError("The guide must match exactly once on either strand of the control. "
                         f"Found {len(matches)} matches.")
    return matches[0]


def read_offset(control, edited, start, stop):
    """Find a unique ungapped upstream anchor. edited[i + offset] matches control[i]."""
    anchor = np.frombuffer(control[start:stop].encode(), dtype="S1")
    target = np.frombuffer(edited.encode(), dtype="S1")
    if len(anchor) < 20 or len(anchor) > len(target):
        raise ValueError("Alignment requires at least 20 upstream bases covered by both reads.")
    scores = np.zeros(len(target) - len(anchor) + 1, dtype=int)
    for b in b"ACGT":
        base = bytes([b])
        scores += correlate((target == base).astype(int), (anchor == base).astype(int), "valid")
    best = int(scores.argmax())
    identity = scores[best] / len(anchor)
    if identity < 0.80 or np.count_nonzero(scores == scores[best]) != 1:
        raise ValueError("No unique upstream alignment with at least 80% identity. "
                         "Check read direction, file pairing and the alignment start.")
    return best - start, float(identity)


def spectrum_csv(result):
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(["indel_bp", "frequency_percent", "approx_p_value"])
    for row in result["spectrum"]:
        writer.writerow([row["size"], row["percent"], row["p"]])
    return output.getvalue()


def trace_segment(read, cut, offset):
    """Map actual scans near the cut onto the control base coordinate axis."""
    lo = max(0, cut + offset - 12)
    hi = min(len(read.locations) - 1, cut + offset + 12)
    scans = np.arange(read.locations[lo], read.locations[hi] + 1)
    bases = np.arange(lo, hi + 1) + 1 - offset
    positions = np.interp(scans, read.locations[lo:hi + 1], bases)
    return {"x": positions.tolist(), "signal": read.scans[scans].T.tolist()}


class TideAnalyzer:
    def __init__(self, control_ab1_file, edited_ab1_file, sgRNA_sequence):
        self.control_file = control_ab1_file
        self.edited_file = edited_ab1_file
        self.sgRNA_sequence = sgRNA_sequence

    def align_traces(self, alignment_start=None, cut_after=None):
        self.control = read_ab1(self.control_file)
        self.edited = read_ab1(self.edited_file)
        if cut_after is None:
            self.cut, self.strand = find_cut(self.control.sequence, self.sgRNA_sequence)
        else:
            if not 1 <= cut_after < len(self.control.sequence):
                raise ValueError("Cut coordinate must be inside the control read.")
            self.cut, self.strand = cut_after, "manual"
        stop = self.cut - 10
        start = max(0, min(99, stop - 40)) if alignment_start is None else alignment_start - 1
        if start < 0 or start >= stop:
            raise ValueError("Alignment start must be a positive base before the cut-site margin.")
        self.offset, self.identity = read_offset(self.control.sequence, self.edited.sequence, start, stop)
        self.anchor = (start, stop)

    def simulate_indels(self, positions, sizes):
        # A deletion advances the reference peak observed at this read position.
        return np.column_stack([self.control.peaks[positions - size].ravel() for size in sizes])

    def decompose_traces(self, max_indel=10, start=None, end=None, alignment_start=None,
                         cut_after=None):
        """Return JSON-compatible results. Optional window bounds are 1-based and inclusive."""
        if not 1 <= max_indel <= 50:
            raise ValueError("Maximum indel size must be between 1 and 50 bp.")
        self.align_traces(alignment_start, cut_after)
        ctrl, edit = self.control.peaks, self.edited.peaks
        common_start = max(0, -self.offset)
        common_end = min(len(ctrl), len(edit) - self.offset)
        minimum = self.cut + max_indel + 5
        maximum = common_end - max_indel - 5
        left = minimum if start is None else start
        right = maximum if end is None else end
        if left < minimum or right > maximum or right - left + 1 < max(20, 2 * max_indel):
            raise ValueError(f"Fit window must lie within bases {minimum}–{maximum} and span "
                             f"at least {max(20, 2 * max_indel)} bases. Reduce the indel range if needed.")
        positions = np.arange(left - 1, right)
        sizes = np.arange(-max_indel, max_indel + 1)
        design = self.simulate_indels(positions, sizes)
        observed = edit[positions + self.offset].ravel()
        if (np.linalg.matrix_rank(design) < len(sizes) or np.var(observed) < 1e-12
                or np.any(observed.reshape(-1, 4).sum(axis=1) == 0)
                or np.any(design.reshape(len(positions), 4, -1).sum(axis=1) == 0)):
            raise ValueError("Insufficient informative signal in the fit window. Choose another window.")
        weights, residual = nnls(design, observed)
        r2 = 1 - residual**2 / np.sum((observed - observed.mean())**2)
        if r2 <= 0 or weights.sum() == 0:
            raise ValueError("The shifted control traces could not explain the edited signal.")
        percent = 100 * r2 * weights / weights.sum()
        # Regression standard errors are approximate for a constrained mixture.
        dof = len(observed) - len(sizes)
        se = residual / np.sqrt(dof) * np.linalg.norm(np.linalg.pinv(design), axis=1)
        stat = np.divide(weights, se, out=np.full_like(weights, np.inf), where=se > 0)
        pvalues = np.where(weights > 0, 2 * t.sf(stat, dof), 1.)
        spectrum = [dict(size=int(s), percent=float(v), p=float(p))
                    for s, v, p in zip(sizes, percent, pvalues)]

        # Fraction of signal inconsistent with the called control base at each position.
        idx = np.arange(common_start, common_end)
        called = np.array([BASES.find(self.control.sequence[i]) for i in idx])
        valid = (called >= 0) & (ctrl[idx].sum(1) > 0) & (edit[idx + self.offset].sum(1) > 0)
        idx, called = idx[valid], called[valid]
        def aberrant(peaks):
            return 100 * (1 - peaks[np.arange(len(idx)), called] / peaks.sum(1))
        control_qc = aberrant(ctrl[idx])
        edited_qc = aberrant(edit[idx + self.offset])
        before = (idx >= self.anchor[0]) & (idx < self.anchor[1])
        if not before.any():
            raise ValueError("No called bases with measurable signal in the upstream alignment.")
        qc_means = [float(v[before].mean()) for v in (control_qc, edited_qc)]
        warnings = []
        if r2 < .9:
            warnings.append("R² is below 0.90. Interpret the fitted frequencies with caution.")
        if max(qc_means) >= 10:
            warnings.append("Mean upstream aberrant signal reaches 10% or more.")
        composition = None
        reason = "The +1 component did not pass the approximate p < 0.001 threshold."
        if pvalues[max_indel + 1] < .001:
            # The first post-cut base contains signal from all insertion lengths.
            # Omit the call when longer insertions contribute significant signal.
            if np.any(pvalues[max_indel + 2:] < .001):
                reason = "Other insertion lengths also contribute signal at the cut."
            else:
                known = sizes <= 0
                background = weights[known] @ ctrl[self.cut - sizes[known]]
                extra = np.maximum(edit[self.cut + self.offset] - background, 0)
                if extra.sum() > 0:
                    composition = dict(zip(BASES, (100 * extra / extra.sum()).tolist()))
                    reason = ""
                else:
                    reason = "No positive insertion signal remained after background subtraction."
        return dict(cut=self.cut, strand=self.strand, offset=self.offset, identity=self.identity,
                    alignment=[self.anchor[0]+1, self.anchor[1]], window=[left, right],
                    r2=float(r2), efficiency=float(percent[sizes != 0].sum()),
                    unexplained=float(100 * (1-r2)), spectrum=spectrum, warnings=warnings,
                    composition=composition, composition_note=reason, upstream=qc_means,
                    qc=dict(x=(idx+1).tolist(), control=control_qc.tolist(), edited=edited_qc.tolist()),
                    traces=[trace_segment(self.control, self.cut, 0),
                            trace_segment(self.edited, self.cut, self.offset)])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", nargs="*", metavar="INPUT",
                        help="Control AB1, edited AB1, and guide. Omit all three for the bundled example.")
    for key in ("max-indel", "start", "end", "alignment-start", "cut-after"):
        parser.add_argument("--" + key, type=int, default=10 if key == "max-indel" else None)
    parser.add_argument("--csv", type=Path, help="Write the full indel spectrum.")
    args = parser.parse_args()
    if len(args.inputs) not in (0, 3):
        parser.error("Supply both AB1 files and the guide together.")
    try:
        result = TideAnalyzer(*(args.inputs or EXAMPLE)).decompose_traces(
            args.max_indel, args.start, args.end, args.alignment_start, args.cut_after)
        if args.csv:
            args.csv.write_text(spectrum_csv(result), encoding="utf-8")
    except (ValueError, OSError) as exc:
        parser.exit(2, f"{exc}\n")
    print(f"Cut after base {result['cut']} | fit {result['window']} | R² {result['r2']:.4f} | "
          f"estimated editing {result['efficiency']:.2f}%")
    print(spectrum_csv(result).strip())
    for warning in result["warnings"]:
        print(warning)


if __name__ == "__main__":
    main()
