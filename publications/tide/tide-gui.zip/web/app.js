"use strict";
const $ = id => document.getElementById(id);
const form = $("inputs");
const tabs = [...document.querySelectorAll("[data-view]")];
let result = null;
let view = 0;
let revision = 0;
const guide = form.elements.guide.defaultValue;

function showView(index) {
  view = index;
  tabs.forEach((tab, i) => tab.setAttribute("aria-pressed", String(i === view)));
  if (!result) return;
  const r = result;
  const captions = [
    "Negative sizes are deletions. Dark blue is the zero-shift component. Teal marks indels with approximate p < 0.001. Frequencies sum to " + (100 - r.unexplained).toFixed(1) + "% (R² × 100).",
    "Control and edited signal inconsistent with the control call. Shading marks the fit window. The dotted line marks the expected cut.",
    "Measured A, C, G and T dye intensities around the cut, aligned to control base positions.",
    r.composition ? Object.entries(r.composition).map(([b, v]) => b + " " + v.toFixed(1) + "%").join("  ·  ") + " (sequenced strand)." : r.composition_note
  ];
  $("plot").src = "data:image/png;base64," + r.images[index];
  $("plot").alt = tabs[index].textContent + ". " + captions[index];
  $("caption").textContent = captions[index];
}

function display(r, example) {
  result = r;
  $("efficiency").textContent = r.efficiency.toFixed(2) + "%";
  $("fit").textContent = r.r2.toFixed(3);
  $("cut").textContent = r.cut;
  $("qc-text").textContent = "Mean upstream aberrant signal across bases " + r.alignment.join("–")
    + "  ·  Control " + r.upstream[0].toFixed(1) + "%  ·  Edited " + r.upstream[1].toFixed(1) + "%";
  $("warning").textContent = r.warnings.join(" ");
  $("warning").hidden = !r.warnings.length;
  const rows = r.spectrum.map(entry => {
    const tr = document.createElement("tr");
    [entry.size > 0 ? "+" + entry.size : entry.size, entry.percent.toFixed(2) + "%", entry.p.toPrecision(3)]
      .forEach(value => { const td = tr.insertCell(); td.textContent = value; });
    return tr;
  });
  $("rows").replaceChildren(...rows);
  const pair = example ? "Example pair" : form.elements.control.files[0].name + " / " + form.elements.edited.files[0].name;
  const location = r.strand === "manual" ? "manual cut" : r.strand + " guide";
  $("status").textContent = pair + "  ·  Fit window " + r.window.join("–") + " bp  ·  " + location + "  ·  offset " + r.offset + " bp";
  $("export").hidden = $("results").hidden = false;
  showView(view);
}

async function analyze(event) {
  if (event) event.preventDefault();
  const requestId = ++revision;
  const example = form.elements.source.value === "example";
  const data = new FormData(form);
  if (example) { data.delete("control"); data.delete("edited"); data.set("example", "1"); }
  result = null;
  $("results").hidden = $("export").hidden = true;
  $("status").className = "";
  $("status").textContent = "Aligning traces and fitting the indel spectrum…";
  $("controls").disabled = true;
  try {
    const response = await fetch("/api/analyze", {method: "POST", body: data});
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || "Analysis failed.");
    if (requestId === revision) display(body, example);
  } catch (error) {
    $("status").className = "error";
    $("status").textContent = error.message;
  } finally { $("controls").disabled = false; }
}

form.addEventListener("input", event => {
  const example = form.elements.source.value === "example";
  $("example-files").hidden = !example;
  $("uploads").hidden = example;
  for (const key of ["control", "edited"]) form.elements[key].required = !example;
  form.elements.guide.required = !form.elements.cut_after.value;
  if (event.target.name === "source" && example) form.elements.guide.value = guide;
  result = null;
  $("results").hidden = $("export").hidden = true;
  $("status").className = "";
  $("status").textContent = "Inputs changed. Analyze traces to update the results.";
});
form.addEventListener("submit", analyze);
tabs.forEach((tab, i) => tab.addEventListener("click", () => showView(i)));
$("export").addEventListener("click", () => {
  if (!result) return;
  const url = URL.createObjectURL(new Blob([result.csv], {type: "text/csv;charset=utf-8"}));
  const link = document.createElement("a");
  link.href = url;
  link.download = "tide-spectrum.csv";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
analyze();
